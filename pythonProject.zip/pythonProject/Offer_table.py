from flask import Flask

from flask_sqlalchemy import SQLAlchemy
from Utils import get_file_offers

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///Offers.db'

db = SQLAlchemy(app)


class Offers(db.Model):
    __tablename__ = 'Offers'

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer)
    executor_id = db.Column(db.Integer)

    def get_file_for_offers(self):
        """
            Добавляем предложения в БД
        """
        file_offers_json = get_file_offers.loging_offers_data()
        for get_offer in file_offers_json:
            offers = Offers(
                id=get_offer['id'],
                order_id=get_offer['order_id'],
                executor_id=get_offer['executor_id']
            )
            with app.app_context():
                db.session.add(offers)
                db.session.commit()

    def all_offers(self):
        """
        Получаем все предложения
        :return:
        """
        with app.app_context():
            all_offers = Offers.query.all()
        list_offers = []
        for offer in all_offers:
            list_offers.append({
                'id': offer.id,
                'order_id': offer.order_id,
                'executor_id': offer.executor_id
            })

        return list_offers

    def one_offer(self, pk):
        """
        Предложение по идентификатору
        :param pk:
        :return:
        """
        with app.app_context():
            one_offer = Offers.query.get(pk)
            if one_offer is None:
                return 'Нет такого предложения'
            get_one_offer = ({
                'id': one_offer.id,
                'order_id': one_offer.order_id,
                'executor_id': one_offer.executor_id
            })
            return get_one_offer

    def add_offer(self, new_offer):
        """
        Добавляем предложение в БД
        :param new_offer:
        """
        get_new_offer = Offers(
            order_id=new_offer['order_id'],
            executor_id=new_offer['executor_id'])

        with app.app_context():
            db.session.add(get_new_offer)
            db.session.commit()

    def update_offer(self, id, result_update):
        """
        Обновляем предложение по идентификатору
        :param id:
        :param result_update:
        :return:
        """
        with app.app_context():
            result_for_delete = self.query.get(id)
            if result_for_delete is None:
                return 'Такого предложения  нет'
            db.session.delete(result_for_delete)
            update_offer_by_id = Offers(
                id=result_update['id'],
                order_id=result_update['order_id'],
                executor_id=result_update['executor_id']
            )

            db.session.add(update_offer_by_id)
            db.session.commit()
        return 'Предложение обновлено'

    def delete_offer_by_id(self, id):
        """
        Удаляет предложение по идентификатору
        :param id:
        """
        with app.app_context():
            result_for_delete = self.query.get(id)
            db.session.delete(result_for_delete)
            db.session.commit()


offer = Offers()


if __name__ == '__main__':
    with app.app_context():
        print(db.session.new)
