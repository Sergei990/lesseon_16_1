from flask import Blueprint, jsonify, render_template, request, redirect
from Orders_table import table_orders

Order = Blueprint('Order', __name__, template_folder='Order')


@Order.get('/orders/')
def all_orders():
    """
    Возвращаем все заказы
    :return:
    """
    get_orders = table_orders.all_orders()
    return jsonify(get_orders)


@Order.get('/one_order/')
def search_oreder():
    return render_template('one_order.html')


@Order.get('/search_order/')
def get_one_order():
    """
    Возвращаем один заказ по идентификатору
    :return:
    """
    s = int(request.args.get('s'))
    answer = table_orders.one_order(s)
    return jsonify(answer)


@Order.get('/add_order/')
def add_order():
    """

    :return:
    """
    return render_template('add_order.html')


@Order.post('/add_order_post/')
def add_order_post():
    """
    Добавляем заказ
    :return:
    """
    result = request.form
    table_orders.add_order(result)
    return redirect('/', 302)


@Order.put('/new_order/<int:id>')
def new_order(id):
    """
    Обновляем заказ по идентификатору
    :param id:
    :return:
    """
    result = table_orders.one_order(id)
    result_new = request.json
    result['name'] = result_new['name']
    result['description'] = result_new['description']
    result['start_date'] = result_new['start_date']
    result['end_date'] = result_new['end_date']
    result['address'] = result_new['address']
    result['price'] = result_new['price']
    result['customer_id'] = result_new['customer_id']
    result['executor_id'] = result_new['executor_id']
    return table_orders.update_order(id, result)


@Order.delete('/del/<int:id>')
def delete(id):
    """
    Удаляем заказ по идентификатору
    :param id:
    :return:
    """
    return table_orders.delete_order(id)
