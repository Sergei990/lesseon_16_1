from Utils import get_file_orders
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///Orders.db'
db = SQLAlchemy(app)


class Orders(db.Model):
    __tablename__ = 'Orders'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    description = db.Column(db.String(300))
    start_date = db.Column(db.Date)
    end_date = db.Column(db.Date)
    address = db.Column(db.String(100))
    price = db.Column(db.Numeric)
    customer_id = db.Column(db.Integer)
    executor_id = db.Column(db.Integer)
    with app.app_context():
        db.drop_all()
        db.create_all()

    def add_all_orders(self):
        """
            Загружаем  данные в БД
        """
        # класс, который корректирует дату для записи БД
        orders = get_file_orders.loging_orders_data()

        for order in orders:
            get_table = Orders(
                id=order['id'],
                name=order['name'],
                description=order['description'],
                start_date=get_file_orders.corrected_date(order['start_date']),
                end_date=get_file_orders.corrected_date(order['end_date']),
                address=order['address'],
                price=order['price'],
                customer_id=order['customer_id'],
                executor_id=order['executor_id']
            )
            with app.app_context():
                db.session.add(get_table)
                db.session.commit()

    def all_orders(self):
        """
        Создайте представление для всех  заказов
        :return:
        """
        with app.app_context():
            get_all_orders = self.query.all()

        all_orders = []

        for order in get_all_orders:
            all_orders.append({

                'id': order.id,
                'name': order.name,
                'description': order.description,
                'start_date': order.start_date,
                'end_date': order.end_date,
                'address': order.address,
                'price': order.price,
                'customer_id': order.customer_id,
                'executor_id': order.executor_id

            })
        return all_orders

    def one_order(self, order):
        """
            Возвращает один заказ по идентификатору
        :param order:
        :return:
        """
        with app.app_context():
            one_order = self.query.get(order)

        if one_order is None:
            not_user = {'key': 'Такого пользователя нет'}
            return not_user
        get_one_order = ({
            'id': one_order.id,
            'name': one_order.name,
            'description': one_order.description,
            'start_date': one_order.start_date,
            'end_date': one_order.end_date,
            'address': one_order.address,
            'price': one_order.price,
            'customer_id': one_order.customer_id,
            'executor_id': one_order.executor_id

        })
        return get_one_order

    def add_order(self, result):
        """
        Добавляем заказ в БД
        :param result:
        """
        add_order = Orders(
            name=result['name'],
            description=result['description'],
            start_date=get_file_orders.corrected_date(result['start_date']),
            end_date=get_file_orders.corrected_date(result['end_date']),
            address=result['address'],
            price=result['price'],
            customer_id=result['customer_id'],
            executor_id=result['executor_id']
        )
        with app.app_context():
            db.session.add(add_order)
            db.session.commit()

    def update_order(self, id, new):
        """
        Обновляем заказ
        :param id:
        :param new:
        :return:
        """
        with app.app_context():
            result_for_update = self.query.get(id)
            if result_for_update is None:
                return 'Такого заказа нет'

            db.session.delete(result_for_update)
            new_data = Orders(
                id=new['id'],
                name=new['name'],
                description=new['description'],
                start_date=get_file_orders.corrected_date(new['start_date']),
                end_date=get_file_orders.corrected_date(new['end_date']),
                address=new['address'],
                price=new['price'],
                customer_id=new['customer_id'],
                executor_id=new['executor_id'])

            db.session.add(new_data)
            db.session.commit()
        return 'Заказ обновлен'

    def delete_order(self, id):
        """
            Удаляем заказ
        :param id:
        :return:
        """
        with app.app_context():
            result_delete_by_id = self.query.get(id)
            if result_delete_by_id is None:
                return 'not_delete'
            db.session.delete(result_delete_by_id)
            db.session.commit()


table_orders = Orders()

if __name__ == '__main__':
    with app.app_context():
        print(db.session.new)
