from flask_sqlalchemy import SQLAlchemy
from flask import Flask
from Utils import get_file_users

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///Users.db'

db = SQLAlchemy(app)


class Users(db.Model):
    __tablename__ = 'User'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    first_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    age = db.Column(db.Integer)
    email = db.Column(db.String(30))
    role = db.Column(db.String(100))
    phone = db.Column(db.String(20))

    def add_table_users(self):
        """ Добавляем json фаил в БД"""
        with app.app_context():
            db.create_all()
        for user in get_file_users.loging_json():
            table_for_users = Users(
                id=user['id'],
                first_name=user['first_name'],
                last_name=user['last_name'],
                age=user['age'],
                email=user['email'],
                role=user['role'],
                phone=user['phone'])
            with app.app_context():
                # db.drop_all()
                db.create_all()
                db.session.add(table_for_users)
                db.session.commit()
        return None

    def get_all_users(self):
        """ получаем всех пользователей из БД"""
        with app.app_context():
            users = Users.query.all()
            respuns_users = []
            for user in users:
                respuns_users.append(
                    {'id': user.id,
                     'first_name': user.first_name,
                     'last_name': user.last_name,
                     'age': user.age,
                     'email': user.email,
                     'role': user.role,
                     'phone': user.phone})

        return respuns_users

    def get_user_by_id(self, pk):
        """один пользователя по идентификатору"""
        with app.app_context():
            one_user = Users.query.get(pk)

            if one_user is None:
                return 'Такого пользователя нет'
        return dict({
            'id': one_user.id,
            'first_name': one_user.first_name,
            'last_name': one_user.last_name,
            'age': one_user.age,
            'role': one_user.role,
            'email': one_user.email,
            'phone': one_user.phone
        })

    def add_user(self, file):
        """Добавляем нового пользователя

        :param file:
        """
        file_users = Users(
            first_name=file['first_name'],
            last_name=file['last_name'],
            age=file['age'],
            email=file['email'],
            role=file['role'],
            phone=file['phone']
        )

        with app.app_context():
            db.session.add(file_users)
            db.session.commit()

    def user_update(self, id, list_new):
        """
            Изменяем данные пользователя
        :param id:
        :param list_new:
        :return:
        """
        with app.app_context():
            result_by_id = self.query.get(id)
            if result_by_id == None:
                return 'Нет такого пользователя'
            # Чтобы при обновлении пользователя не изменялся id
            db.session.delete(result_by_id)
            new_user_ = Users(
                id=id,
                first_name=list_new['first_name'],
                last_name=list_new['last_name'],
                age=list_new['age'],
                role=list_new['role'],
                email=list_new['email'],
                phone=list_new['phone']
            )

            db.session.add(new_user_)
            db.session.commit()
        return 'Пользователь обновлен'

    def delete_user(self, pk):
        """
        Удаляем пользователя
        :param pk:intger
        :return:
        """
        with app.app_context():
            del_user = Users.query.get(pk)
            if del_user == None:
                return 'Такого пользователя нет.'
            db.session.delete(del_user)
            db.session.commit()
            return 'Пользователь удален'


users_table = Users()

all_users = users_table.get_all_users()
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    print(all_users)
