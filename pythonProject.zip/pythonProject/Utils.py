import json
import datetime


class Users:

    def __init__(self, trac):
        self.trac = trac
        """ Исправляем фаил с текста в JSON для добавления в БД
        """
        # считываваем фаел txt
        with open(self.trac, encoding='UTF-8') as file:
            # исправляем фаил для json
            old_file = file.read().replace("'", '"')
        # записываем исправленный филе
        with open('new_data/Users.json', 'w', encoding='UTF-8') as file:
            corrected_data = file.write(old_file)
            # добавляем фаил
            json.dumps(corrected_data)

    def loging_json(self):
        # загружаем фаил для добавленя в бд
        with open('new_data/Users.json', encoding='UTF-8') as file:
            return json.load(file)


class Orders:
    """ Исправляем фаил с текста в JSON для добавления в БД
            """

    def __init__(self, trac):

        self.trac = trac
        # Читаем фаил и испрaвляем для JSON
        with open(self.trac, encoding='UTF-8') as file:
            new_data = file.read().replace("'", '"')
        # Записываем исправленный фаил
        with open('new_data/Orders.json', 'w', encoding='UTF-8') as file:
            corrected_data = file.write(new_data)
            json.dumps(corrected_data)

    def loging_orders_data(self):
        """Загружаем фаил JSON"""
        with open('new_data/Orders.json', encoding='UTF-8') as file:
            return json.load(file)

    def corrected_date(self, old_date):
        """Корректируем формат даты для добавления в таблицу SQL"""
        # self.date = old_date
        if '/' in old_date:
            list_date = old_date.split('/')
            list_date.reverse()
            for index, value in enumerate(list_date):

                if value[0] in '0':
                    date_corrected = value.replace('0', '')
                    list_date[index] = date_corrected
            yar, day, month = list_date
            result = datetime.date(int(yar), int(month), int(day))
            return result
        else:
            result_yar_moon_day = old_date.split('-')

            yar, moon, day = result_yar_moon_day

            return datetime.date(int(yar), int(moon), int(day))


class Offers:
    """ Исправляем фаил с текста в JSON
    для добавления в БД
                """

    def __init__(self, trac):
        self.trac = trac
        #
        with open(self.trac, encoding='UTF-8') as file:
            new_file = file.read().replace("'", '"')
        #
        with open('new_data/Offers.json', 'w', encoding='UTF-8') as file:
            corrected_file = file.write(new_file)
            json.dumps(corrected_file)

    def loging_offers_data(self):
        #
        with open('new_data/Offers.json', encoding='UTF-8') as file:
            return json.load(file)


get_file_users = Users('data/Users.txt')
get_file_orders = Orders('data/Orders.txt')
get_file_offers = Offers('data/Offers.txt')
