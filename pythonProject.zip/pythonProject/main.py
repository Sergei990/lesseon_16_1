from flask import Flask

from offer.offer_blueprint import Offer
from users_blueprint.users_blueprint import users_blueprint
from Order_blueprint.order_blueprint import Order

app = Flask(__name__)
app.register_blueprint(users_blueprint)
app.register_blueprint(Order)
app.register_blueprint(Offer)
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=3000, debug=True)
