from flask import Blueprint, render_template, jsonify, request, redirect
from Offer_table import offer

Offer = Blueprint('Offer', __name__, template_folder='template_offer')


@Offer.get('/all_offer/')
def all_offer():
    """
    Получаем все заказы
    :return:
    """
    all_offer = offer.all_offers()
    return jsonify(all_offer)


@Offer.get('/searhc/')
def search_one_offer():
    """

    :return:
    """
    return render_template('search_offer.html')


@Offer.get('/one_offer/')
def get_one_offer():
    """
    Возвращаем одно предложение по индикатору
    :return:
    """
    s = int(request.args.get('s'))
    one_offer = offer.one_offer(s)
    return jsonify(one_offer)


@Offer.get('/add_offer/')
def add_offer():
    return render_template('add_offer.html')


@Offer.post('/add_offer_post/')
def add_offer_post():
    """
    Добавляем предложение
    :return:
    """
    result_offer = request.form
    offer.add_offer(result_offer)
    return redirect('/', 302)


@Offer.put('/offers/<int:id>')
def offers_update(id):
    """
    Обновляем предложение
    :param id:
    :return:
    """
    get_offer_by_id = offer.one_offer(id)
    result_update = request.json
    get_offer_by_id['id'] = id
    get_offer_by_id['order_id'] = result_update['order_id']
    get_offer_by_id['executor_id'] = result_update['executor_id']
    offer.update_offer(id, get_offer_by_id)
    return jsonify(get_offer_by_id)


@Offer.delete('/offers/<int:id>')
def delete_offer(id):
    """
    Удаляем предложение по идентификатору
    :param id:
    :return:
    """
    offer.delete_offer_by_id(id)
    return 'Предложение удалено'
