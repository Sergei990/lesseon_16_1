import json

from flask import Blueprint, jsonify, render_template, request, redirect

from Utils import get_file_users
from Users_table import all_users, users_table

all_users_ = all_users

users_blueprint = Blueprint('users_bluprint', __name__, template_folder='templates')

i = get_file_users.loging_json()


@users_blueprint.get('/')
def index():
    return render_template('index.html')


@users_blueprint.get('/users/')
def all_users():
    """
    Получаем всех пользователей
    :return:
    """
    return jsonify(all_users_)


@users_blueprint.get('/one_user/')
def one_users():
    return render_template('one_users.html')


@users_blueprint.get('/search_user/')
def search_user():
    """
    Получаем одного пользователя  по идентификатору
    :return:
    """
    # try:
    s = int(request.args.get('s'))
    result = users_table.get_user_by_id(s)
    return jsonify(result)


@users_blueprint.get('/add_user/')
def add_user():
    return render_template('add_user.html')


@users_blueprint.post('/added_user/')
def added_user():
    """
    Добавляем пользователя
    :return:
    """
    list_add = dict(first_name=request.form['first_name'],
                    last_name=request.form['last_name'],
                    age=request.form['age'],
                    email=request.form['email'],
                    role=request.form['role'],
                    phone=request.form['phone'])

    users_table.add_user(list_add)
    return redirect('/', code=302)


@users_blueprint.get('/new_user/')
def new_user():
    return render_template('news_user.html')


@users_blueprint.put('/new_user_/<int:id>')
def update_user(id):
    """
    Обновляем пользователя
    :param id:
    :return:
    """
    new_data_user = request.json
    result = users_table.get_user_by_id(id)
    result['first_name'] = new_data_user['first_name']
    result['last_name'] = new_data_user['last_name']
    result['age'] = new_data_user['age']
    result['email'] = new_data_user['email']
    result['role'] = new_data_user['role']
    result['phone'] = new_data_user['phone']
    return users_table.user_update(id, result)



@users_blueprint.delete('/user_del/<int:pk>/')
def user_delete(pk):
    """
    Удаляем пользователя по идентификатору
    :param pk:
    :return:
    """
    user_del = users_table.delete_user(pk)

    return user_del


if __name__ == '__main__':
    print(added_user(), i)
